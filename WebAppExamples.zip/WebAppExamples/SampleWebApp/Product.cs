﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SampleWebApp
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int Price { get; set; }
        public short Quantity { get; set; } = 1;//Property assignment in C# 7.0

        public override int GetHashCode()
        {
            return ProductName.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            var temp = obj as Product;
            return ProductName == temp.ProductName;
        }
    }

    public class Repository
    {
        private DataSet ds = null;
        private HashSet<Product> _products = new HashSet<Product>();

        //Disconnected model of database...
        public Repository()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["myDiscon"].ConnectionString;
            var query = "SELECT * from ProductTable";
            var adapter = new SqlDataAdapter(query, connectionString);
            ds = new DataSet();
            adapter.Fill(ds, "FirstTable");//Opens the closed connection, fills the data into the table specified and immediately closes the connection...
        }

        public List<Product> AllProducts
        {
            get
            {
                getAllproducts();
                return _products.ToList();
            }
        }

        private void getAllproducts()
        {
            foreach(DataRow row in ds.Tables["FirstTable"].Rows)
            {
                var product = new Product
                {
                    ProductID = Convert.ToInt32(row[0]),
                    ProductName = row[1].ToString(),
                    Price = Convert.ToInt32(row[2])
                };
                _products.Add(product);
            }
        }
    }
}