﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace SampleWebApp
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            //create the object for storing all the products from the database. 
            var com = new Repository();
            var data = com.AllProducts.OrderBy((p)=>p.ProductName).ToList();
            Application["Products"] = data;//We have filled our Application object with data under a key called Products. 
        }

        //Event handler for session start...
        protected void Session_Start(object sender, EventArgs e)
        {
            Session.Add("myCart", new List<Product>());
            Session.Add("recent", new Queue<Product>());
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}