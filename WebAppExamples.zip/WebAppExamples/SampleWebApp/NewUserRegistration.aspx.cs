﻿using EntityDataLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebApp
{
    public partial class NewUserRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsValid)
                    return;
                var com = DataFactory.GetComponent();
                var row = new UserTable
                {
                    UserID = 112,
                    Username = txtName.Text,
                    Password = txtPwd.Text,
                    Qualification = dpList.Text,
                    UserAge = int.Parse(txtAge.Text),
                    UserEmail = txtEmail.Text
                };
                com.RegisterUser(row);
                lblErrorInfo.Text = "User registered Successfully";
            }
            catch (Exception ex)
            {
                lblErrorInfo.Text = ex.Message;
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var emailToValidate = args.Value;
            var com = DataFactory.GetComponent();
            var @check = com.CheckForUniqueEmail(emailToValidate);
            args.IsValid = check;
            if (check)
                lblErrorInfo.Text = "is valid";
            else
                lblErrorInfo.Text = "Invalid";
        }
    }
}