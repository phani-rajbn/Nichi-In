﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLib
{
    public interface IDataComponent
    {
        bool CheckForUniqueEmail(string email);
        UserTable LoginUser(string username, string password);
        void RegisterUser(UserTable user);
    }

    class DataComponent : IDataComponent
    {
        public void RegisterUser(UserTable user)
        {
           
            var context = new MyDBEntities();
            var temp = context.UserTables.Max((u) => u.UserID);
            user.UserID = temp + 1;
            context.UserTables.Add(user);
            context.SaveChanges();
        }

        public bool CheckForUniqueEmail(string email)
        {
            var context = new MyDBEntities();
            var selected = context.UserTables.FirstOrDefault((u) => u.UserEmail == email);
            return selected == null;
        }

        public UserTable LoginUser(string username, string password)
        {
            var context = new MyDBEntities();
            var selected = context.UserTables.FirstOrDefault((u) => ((u.Username == username) && (u.Password == password)));
            if (selected == null) throw new Exception("Login failed for the User");
            return selected;
        }
    }

    public static class DataFactory
    {
        public static IDataComponent GetComponent()
        {
            return new DataComponent();
        }
    }
}
