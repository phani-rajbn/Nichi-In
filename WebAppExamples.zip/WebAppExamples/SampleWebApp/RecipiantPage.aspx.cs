﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebApp
{
    public partial class RecipiantPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*
            if (Request.QueryString.Count == 0)
                lblDisplay.Text = "User details are not set";
            else
                lblDisplay.Text = $"The Name: {Request.QueryString["Name"]}<br/>The Email Address: {Request.QueryString[1]}";
            
             * Querystring is the simplest way of transfering data from one page to another. 
             * Viewers can view the data even from History. 
             * Viewers can modify the data. 
             * Data is always in the form of text only. Certain browsers restrict the size of the url to be upto 255 charecters only. 
             * To store data in a more secured way, u should use cookies.
             ****************************Cookies**********************************
            if (Request.Cookies["MyData"] == null)
                lblDisplay.Text = "User details are not set or stored as cookie in Ur machine";
            else
                lblDisplay.Text = $"The Name: {Request.Cookies["MyData"].Values[0]}<br/>The Email Address: {Request.Cookies["MyData"].Values["Email"]}";
            /*
             * As Many users are unaware about the cookies, so there is little security issue. However cookies are not to store secured data like passwords. 
             * Cookies can be disabled by the User of the machine. U cannot rely on cookies all the time. 
             * Cookies can be destroyed by the User, so be ready for such anomalies where U must ask the user to allow the App to store the cookies. 
             * Default expiration of a cookie is for 1 yr. U can programmatically set the duration of cookie.
             */
            if (PreviousPage == null)
                lblDisplay.Text = "This page is directly viewed, it is not posted data!!!!";
            else
                lblDisplay.Text = $"The Name: {PreviousPage.Username.Text}<br/>The Email Address: {PreviousPage.EmailAddress.Text}";
        }
    }
}