﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebApp
{
    public partial class EntryPage : System.Web.UI.Page
    {
        public TextBox Username
        {
            get
            {
                return txtName;
            }
        }

        public TextBox EmailAddress
        {
            get
            {
                return txtEmail;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            /********************Querystring************************************
            var url = $"RecipiantPage.aspx?Name={txtName.Text}&Email={txtEmail.Text}";
            Response.Redirect(url);
            //Response.Redirect is a method used to redirect the Url to another page. It works similar to hyperlink's href. 
            *******************Using Cookies*****************************
            HttpCookie example = new HttpCookie("MyData");//create the cookie
            //example.Expires = DateTime.Now.AddSeconds(100);
            example.Values.Add("Name", txtName.Text);//fill the data into the object
            example.Values.Add("Email", txtEmail.Text);
            Response.Cookies.Add(example);//add the cookie to the response
            Response.Redirect("RecipiantPage.aspx");//redirect to the viewing page.
            */
        }
    }
}