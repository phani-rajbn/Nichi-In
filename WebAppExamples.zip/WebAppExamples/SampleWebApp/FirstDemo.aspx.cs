﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace SampleWebApp
{
    public partial class FirstDemo : System.Web.UI.Page
    {
        private void clearTextFields()
        {
            txtAge.Text = string.Empty;
            txtName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            //var form = Controls[0] as HtmlForm;
            //foreach (var ctrl in form.Controls)
            //{
            //    if (ctrl is TextBox)
            //    {
            //        var txt = ctrl as TextBox;
            //        txt.Text = "";
            //    }
            //}
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
                clearTextFields();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            lblInfo.Text = $"The name: {txtName.Text}<br/>The Email: {txtEmail.Text}<br/>The Age: {txtAge.Text}";
            
        }
    }
}