﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebApp
{
    public partial class FinalBilling : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var cart = Session["myCart"] as List<Product>;
            rpFinal.DataSource = cart;
            rpFinal.DataBind();
            lblFinal.Text = $"Amount:{cart.Sum((p) => p.Price):C}";
        }
    }
}