﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLib
{
    public interface IDataComponent
    {
        List<EmpTable> GetAllEmployees();
        EmpTable GetEmployee(int id);
        void AddNewEmployee(EmpTable emp);
        void DeleteEmployee(int empID);
        void UpdateEmployee(EmpTable emp);

    }
    class DataComponent : IDataComponent
    {
        public void AddNewEmployee(EmpTable emp)
        {
            var context = new EmpEntities();
            context.EmpTables.Add(emp);
            context.SaveChanges();
        }

        public void DeleteEmployee(int empID)
        {
            var context = new EmpEntities();
            var selected = context.EmpTables.FirstOrDefault((e) => e.EmpID == empID);
            if (selected == null) throw new Exception("Employee not found to delete");
            context.EmpTables.Remove(selected);
            context.SaveChanges();
        }

        public List<EmpTable> GetAllEmployees()
        {
            return new EmpEntities().EmpTables.ToList();
        }

        public EmpTable GetEmployee(int id)
        {
            var context = new EmpEntities();
            var selected = context.EmpTables.FirstOrDefault((e) => e.EmpID == id);
            if (selected == null) throw new Exception("Employee not found");
            return selected;
        }

        public void UpdateEmployee(EmpTable emp)
        {
            var context = new EmpEntities();
            var selected = context.EmpTables.FirstOrDefault((e) => e.EmpID == emp.EmpID);
            if (selected == null) throw new Exception("Employee not found to update");
            selected.Empname = emp.Empname;
            selected.Empsalary = emp.Empsalary;
            selected.Empaddress = emp.Empaddress;
            context.SaveChanges();
        }
    }

    public static class DataFactory
    {
        public static IDataComponent GetComponent()
        {
            return new DataComponent();
        }
    }
}
