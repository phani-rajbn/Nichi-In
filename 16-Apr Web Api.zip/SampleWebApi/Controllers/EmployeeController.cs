﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EntityDataLib;
using SampleWebApi.Models;

namespace SampleWebApi.Controllers
{
    public class EmployeeController : ApiController
    {
        static IDataComponent component = DataFactory.GetComponent();//Singleton object...

        public List<Employee> GetEmployees()
        {
            var data = component.GetAllEmployees();//List<EmpTable>
            var empList = data.Select((e) => new Employee {
                EmpID = e.EmpID, Empaddress = e.Empaddress, Empname = e.Empname, Empsalary = e.Empsalary
            }).ToList();
            return empList;
        }

        private Employee Convert(EmpTable rec)
        {
            return new Employee
            {
                EmpID = rec.EmpID,
                Empaddress = rec.Empaddress,
                Empname = rec.Empname,
                Empsalary = rec.Empsalary
            };
        }
        [HttpGet]
        public Employee Find(string id)
        {
            int empId = int.Parse(id);
            var rec = component.GetEmployee(empId);
            var emp = Convert(rec);
            return emp;
        }

        [Route("api/Customers")]
        public Employee GetCustomers()
        {
            return new Employee { Empname = "Use this for multiple gets only" };
        }
    }
}
