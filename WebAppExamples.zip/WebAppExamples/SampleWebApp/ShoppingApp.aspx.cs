﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebApp
{
    public partial class ShoppingApp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var data = Application["Products"] as List<Product>;
                lstItems.DataSource = data;
                lstItems.DataTextField = "ProductName";
                lstItems.DataValueField = "ProductID";
                lstItems.DataBind();//DataBind function is used to populate the data into the elements. 
            }
        }

        protected void lstItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            var data = Application["Products"] as List<Product>;//get the application object
            findItem(data);
            var selecedID = Convert.ToInt32(lstItems.SelectedValue);//extract the id of the selected product
            var selectedItem = data.Find((p) => p.ProductID == selecedID);//find the selected item based on id from the application data...
            var recent = Session["recent"] as Queue<Product>;
            if (recent.Count == 5)
                recent.Dequeue();
            recent.Enqueue(selectedItem);
            Session["recent"] = recent;
            dlRecent.DataSource = recent.Reverse().ToList();
            dlRecent.DataBind();
        }

        private void findItem(List<Product> data)
        {
            var selecedID = Convert.ToInt32(lstItems.SelectedValue);//extract the id of the selected product

            var selectedItem = data.FindAll((p) => p.ProductID == selecedID);//find the selected item based on id from the application data...
            details.DataSource = selectedItem;//set the datasource to the data extracted from application data..
            details.DataBind();//bind the object....
        }

        protected void details_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            if(e.CommandName == "AddItem")//if the clicked button is AddItem
            {
                var selectedID = Convert.ToInt32(lstItems.SelectedValue);//extract the id of the selected product
                var data = Application["Products"] as List<Product>;//get the application object
                var selectedItem = data.Find((p) => p.ProductID == selectedID);//find the matching item
                var cart = Session["myCart"] as List<Product>;//get the session object
                cart.Add(selectedItem);//add the selected item to the session data.
                lblTotal.Text = $"Amount:{cart.Sum((p) => p.Price * p.Quantity):C}";
                Session["myCart"] = cart;//reset the data to session
                lblCount.Text = "Total: " + cart.Count;//Display the count of the items...
            }
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            Response.Redirect("FinalBilling.aspx");
        }
    }
}